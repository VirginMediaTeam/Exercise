﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CodeExcercise
{
    [TestClass]
    public class MyTestClass
    {
        [TestMethod]
        public void Test1()
        {
            var employees = new List<Employee>()
            {
                new StandardUser() { FirstName = "Jim", LastName = "Rogers", totalLogins = 10, LastLogin = DateTime.Now},
                new StandardUser() { FirstName = "Tony", LastName = "Smith",totalLogins = 10, LastLogin = new DateTime(2017, 12, 13)},
                new Admin () { FirstName = "Steve", LastName = "Roberts", totalLogins = 20, LastLogin = new DateTime(2018, 1, 6) }
            };

            new Employee().printReport(employees, "LoginReport.csv");
            var outEmployees = File.ReadAllLines("LoginReport.csv");

            Assert.AreEqual(4, outEmployees.Count());
        }
    }
    
    public class Employee : User
    {
        public int totalLogins;
        public DateTime LastLogin;

        // NOTE: This method prints employees login report in csv format.
        public void printReport(IEnumerable<Employee> employees, string filename)
        {
            List<string> entries = new List<string>();
            entries.Add("Username,Last Login,Total Logins");
            foreach (var e in employees)
            {
                var entry = string.Join(" ", e.FirstName, e.LastName) + e.LastLogin + "," + e.totalLogins;
                if (e is Admin)
                {
                    var admin = e as Admin;
                    entry += "," + admin.LastLogin;
                }

                entries.Add(entry);
            }
            File.WriteAllLines(filename, entries.ToArray());
        }
    }

    public class StandardUser : Employee
    {

        public bool HaveBasicAccess;
    }

    public class Admin : Employee
    {
        public bool HaveBasicAccess;
        public bool HaveAdminAccess;
    }
    
    public class User
    {
        public string FirstName;

        public string LastName;
    }

}
